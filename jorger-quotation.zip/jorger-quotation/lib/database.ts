import { createServerClient } from '@supabase/ssr'
import { cookies } from 'next/headers'

export async function database() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL
  const key = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY
  if (!url || !key) return null
  const jar = await cookies()
  return createServerClient(url, key, {
    cookies: {
      getAll: () => jar.getAll(),
      setAll: (values) => {
        try {
          for (const { name, value, options } of values) jar.set(name, value, options)
        } catch {
          // Server Components have a read-only cookie store.
        }
      },
    },
  })
}

export async function adminContext() {
  const db = await database()
  if (!db) return { db: null, user: null, admin: false }
  const { data: { user } } = await db.auth.getUser()
  const membership = user ? await db.from('admins').select('user_id').eq('user_id', user.id).maybeSingle() : null
  return { db, user, admin: !!membership?.data }
}

