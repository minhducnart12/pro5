export type Product = {
  id: string
  sku: string
  name: string
  line: 'fluorocarbon' | 'eco'
  kind: 'part' | 'set'
  system: string
  door_type: string
  finish: string
  description: string
  image_url: string
  price: number
  active: boolean
}

export type Order = {
  id: string
  kind: 'quote' | 'order'
  customer: string
  phone: string
  notes: string
  status: string
  total: number
  created_at: string
  order_items: { sku: string; name: string; quantity: number; unit_price: number }[]
}

export const money = (value: number) => new Intl.NumberFormat('vi-VN', {
  style: 'currency', currency: 'VND', maximumFractionDigits: 0,
}).format(value)

export function discountRate(fluorocarbon: number) {
  if (fluorocarbon >= 10_000_000) return 35
  if (fluorocarbon >= 5_000_000) return 32
  return fluorocarbon > 0 ? 30 : 0
}

export function imagePath(value: string) {
  if (value.startsWith('/products/') && /^\/products\/[a-zA-Z0-9._-]+$/.test(value)) return value
  try {
    const url = new URL(value)
    if (url.protocol === 'https:' && !url.username && !url.password) return url.href
  } catch {}
  return ''
}
