'use client'

import { useEffect, useState } from 'react'
import { ArrowDown, ArrowRight, Check, DoorOpen, Package, Plus, Search, ShieldCheck, ShoppingBag, X } from 'lucide-react'
import Link from 'next/link'
import { submitRequest } from '../app/actions'
import { discountRate, imagePath, money, type Product } from '../lib/catalog'

const lines = [
  { id: 'fluorocarbon', name: 'Fluorocarbon', caption: 'HOÀN THIỆN CAO CẤP', description: 'Lớp sơn bền bỉ. Ưu đãi 30–35% theo giá trị giỏ hàng.' },
  { id: 'eco', name: 'Eco', caption: 'VỪA VẶN NGÂN SÁCH', description: 'Phụ kiện JORGER với mức giá niêm yết dễ lựa chọn.' },
] as const

export function Storefront({ products, offline }: { products: Product[]; offline: boolean }) {
  const [line, setLine] = useState<Product['line']>('fluorocarbon')
  const [cart, setCart] = useState<Record<string, number>>({})
  const [restored, setRestored] = useState(false)
  const [system, setSystem] = useState('')
  const [door, setDoor] = useState('')
  const [query, setQuery] = useState('')
  const [busy, setBusy] = useState(false)
  const [receipt, setReceipt] = useState<{ id: string; total: number }>()
  const [error, setError] = useState('')
  const [requestId, setRequestId] = useState('')
  const [detail, setDetail] = useState<Product>()

  useEffect(() => {
    try {
      const raw: Record<string, unknown> = JSON.parse(localStorage.getItem('jorger-quotation-cart') ?? '{}')
      setCart(Object.fromEntries(Object.entries(raw).filter(([, value]) => Number.isInteger(value) && Number(value) > 0 && Number(value) <= 1000)) as Record<string, number>)
    } catch {}
    setRestored(true)
  }, [])

  useEffect(() => {
    if (restored && !offline) localStorage.setItem('jorger-quotation-cart', JSON.stringify(cart))
  }, [cart, restored, offline])

  const selected = products.filter(p => cart[p.id] > 0)
  const subtotal = selected.reduce((sum, p) => sum + p.price * cart[p.id], 0)
  const eligible = selected.reduce((sum, p) => sum + (p.line === 'fluorocarbon' ? p.price * cart[p.id] : 0), 0)
  const rate = discountRate(eligible)
  const discount = Math.floor(eligible * rate / 100)
  const count = selected.reduce((sum, p) => sum + cart[p.id], 0)
  const catalog = products.filter(p => p.line === line)
  const featured = catalog.find(p => imagePath(p.image_url))
  const sets = catalog.filter(p => p.kind === 'set')
  const systems = [...new Set(sets.map(p => p.system))]
  const doors = [...new Set(sets.filter(p => p.system === system).map(p => p.door_type))]
  const parts = catalog.filter(p => p.kind === 'part' && `${p.name} ${p.sku} ${p.finish}`.toLocaleLowerCase('vi').includes(query.trim().toLocaleLowerCase('vi')))

  function change(id: string, delta: number) {
    if (busy) return
    setReceipt(undefined)
    setRequestId('')
    setCart(previous => {
      const next = { ...previous }
      const quantity = Math.min(1000, (next[id] ?? 0) + delta)
      if (quantity > 0) next[id] = quantity
      else delete next[id]
      return next
    })
  }

  function cards(items: Product[]) {
    return <div className="product-grid">{items.map(p => {
      const image = imagePath(p.image_url)
      return <article className="product panel" key={p.id}>
        <button className="product-image" onClick={() => setDetail(p)} aria-label={`Xem ${p.name}`}>
          {image ? <img src={image} alt={p.name} loading="lazy" /> : <Package size={40} strokeWidth={1} />}
        </button>
        <div className="product-copy"><span className="eyebrow">{p.sku} {p.finish && `· ${p.finish}`}</span><h3>{p.name}</h3>
          <div className="product-bottom"><strong>{money(p.price)}</strong><button className="button icon" type="button" aria-label={`Thêm ${p.name}`} onClick={() => change(p.id, 1)} disabled={busy}><Plus size={18} /></button></div>
        </div>
      </article>
    })}</div>
  }

  return <>
    <header className="header"><div className="wrap header-inner">
      <a href="#" aria-label="JORGER Quotation"><img className="logo" src="/brand/jorger-logo.png" alt="JORGER" /></a>
      <nav aria-label="Điều hướng"><a href="#config">Chọn bộ cửa</a><a href="#parts">Mua mã lẻ</a><Link href="/admin">Quản trị</Link></nav>
      <a className="button cart-link" href="#cart"><ShoppingBag size={17} /> Giỏ hàng <span>{count}</span></a>
    </div></header>
    <main>
      <section className="hero wrap">
        <div className="hero-copy">
          <div className="eyebrow">JORGER / BÁO GIÁ & ĐẶT HÀNG</div>
          <h1>Chọn phụ kiện.<br /><em>Hoàn thiện bộ cửa.</em></h1>
          <p>Chọn dòng phụ kiện phù hợp, cấu hình theo hệ nhôm và loại cửa, rồi xem ngay giá cho công trình của bạn.</p>
          <a href="#config" className="button primary">Cấu hình bộ cửa <ArrowRight size={18} /></a>
        </div>
        <div className="hero-visual">
          <div className="hero-tag">JORGER COLLECTION</div>
          {featured ? <img src={imagePath(featured.image_url)} alt={featured.name} fetchPriority="high" /> :
            <img src="/products/D11009.webp" alt="" fetchPriority="high" />}
          {featured && <div className="hero-caption"><strong>{featured.name}</strong><span>{line.toUpperCase()}</span></div>}
        </div>
      </section>
      <div className="wrap content">
        <section aria-labelledby="line-heading">
          <h2 id="line-heading">Chọn dòng phụ kiện</h2>
          <div className="line-grid">{lines.map(item => <button type="button" key={item.id} aria-pressed={line === item.id} className={`line-card panel ${line === item.id ? 'active' : ''}`} onClick={() => { setLine(item.id); setSystem(''); setDoor(''); setQuery('') }}>
            <span className="eyebrow">{item.caption}</span><span className="line-name">{item.name}</span><span className="line-description">{item.description}</span><span className="selection">{line === item.id && <Check size={13} />}</span>
          </button>)}</div>
        </section>
        <section className="benefits" aria-label="Ưu đãi Fluorocarbon">
          <div><div className="eyebrow">ƯU ĐÃI FLUOROCARBON</div><strong>Giảm đến 35%</strong></div>
          <div><strong>30%</strong><small>Dưới 5 triệu</small></div>
          <div><strong>32%</strong><small>Từ 5 đến dưới 10 triệu</small></div>
          <div><strong>35%</strong><small>Từ 10 triệu</small></div>
        </section>
        {offline && <p className="notice" role="status">Danh mục hiện chưa khả dụng. Giá và cấu hình sẽ xuất hiện khi cơ sở dữ liệu được kết nối.</p>}
        <section id="config" className="section">
          <div className="section-head"><div><div className="eyebrow">THEO CẤU HÌNH CỬA</div><h2>Cấu hình bộ cửa</h2></div><DoorOpen size={29} strokeWidth={1.3} /></div>
          <div className="filters panel">
            <label>Hệ nhôm<select value={system} onChange={e => { setSystem(e.target.value); setDoor('') }} disabled={!systems.length}><option value="">Chọn hệ nhôm</option>{systems.map(value => <option key={value}>{value}</option>)}</select></label>
            <label>Loại cửa<select value={door} onChange={e => setDoor(e.target.value)} disabled={!system}><option value="">Chọn loại cửa</option>{doors.map(value => <option key={value}>{value}</option>)}</select></label>
          </div>
          {door && cards(sets.filter(p => p.system === system && p.door_type === door))}
          {!offline && !systems.length && <p className="muted">Dòng này chưa có bộ cửa.</p>}
        </section>
        <section id="parts" className="section">
          <div className="section-head"><div><div className="eyebrow">THEO MÃ SẢN PHẨM</div><h2>Mua mã lẻ</h2></div><ArrowDown size={26} strokeWidth={1.3} /></div>
          <label className="search"><Search size={19} /><input aria-label="Tìm phụ kiện" placeholder="Tìm tên, mã sản phẩm hoặc màu…" value={query} onChange={e => setQuery(e.target.value)} /></label>
          {cards(parts)}
          {!offline && !parts.length && <p className="muted">Không tìm thấy phụ kiện phù hợp.</p>}
        </section>
        <section id="cart" className="section">
          <div className="section-head"><div><div className="eyebrow">BÁO GIÁ & ĐẶT HÀNG</div><h2>Giỏ hàng</h2></div><ShoppingBag size={27} strokeWidth={1.3} /></div>
          {receipt && <p className="notice" role="status">Đã gửi yêu cầu <strong>{receipt.id}</strong>. Tổng ghi nhận: <strong>{money(receipt.total)}</strong>.</p>}
          {selected.length ? <div className="checkout">
            <div className="panel box">
              {selected.map(p => <div className="cart-row" key={p.id}><div><strong>{p.name}</strong><small>{p.sku} · {money(p.price)}</small></div><div className="quantity"><button type="button" aria-label={`Giảm ${p.name}`} disabled={busy} onClick={() => change(p.id, -1)}>−</button>{cart[p.id]}<button type="button" aria-label={`Tăng ${p.name}`} disabled={busy} onClick={() => change(p.id, 1)}>+</button></div></div>)}
              <dl className="totals"><div><dt>Tạm tính</dt><dd>{money(subtotal)}</dd></div><div><dt>Ưu đãi Fluorocarbon {rate}%</dt><dd>−{money(discount)}</dd></div><div><dt>Tổng dự kiến</dt><dd>{money(subtotal - discount)}</dd></div></dl>
              <small className="muted">Giá đã gồm VAT, chưa gồm vận chuyển.</small>
            </div>
            <form className="panel box form" onSubmit={async e => {
              e.preventDefault()
              if (busy) return
              const form = new FormData(e.currentTarget, (e.nativeEvent as SubmitEvent).submitter)
              const id = requestId || crypto.randomUUID()
              setRequestId(id)
              setBusy(true)
              setError('')
              try {
                const result = await submitRequest(form, selected.map(p => ({ product_id: p.id, quantity: cart[p.id] })), id)
                if (result.receipt) {
                  setReceipt(result.receipt); setCart({}); setRequestId('')
                } else setError(result.error ?? 'Chưa thể gửi yêu cầu.')
              } catch {
                setError('Kết nối bị gián đoạn. Vui lòng thử lại.')
              } finally { setBusy(false) }
            }}>
              <label>Họ tên<input name="customer" autoComplete="name" required minLength={2} maxLength={120} /></label>
              <label>Số điện thoại<input name="phone" type="tel" autoComplete="tel" required minLength={8} maxLength={25} /></label>
              <label>Ghi chú<textarea name="notes" maxLength={1500} rows={3} /></label>
              {error && <p role="alert">{error}</p>}
              <div className="actions"><button className="button" name="kind" value="quote" disabled={busy}>Yêu cầu báo giá</button><button className="button primary" name="kind" value="order" disabled={busy}>Gửi đơn hàng</button></div>
            </form>
          </div> : !receipt && <div className="panel box muted">Giỏ hàng đang trống.</div>}
          <p className="trust"><ShieldCheck size={19} /> JORGER kiểm tra kích thước, hướng mở và phụ kiện trước khi xác nhận đơn.</p>
        </section>
      </div>
    </main>
    <footer><div className="wrap"><img className="logo" src="/brand/jorger-logo.png" alt="JORGER" /><span>Phụ kiện cửa · Fluorocarbon & Eco</span><Link href="/admin">Khu vực quản trị ↗</Link></div></footer>
    {detail && <dialog ref={element => { if (element && !element.open) element.showModal() }} onClose={() => setDetail(undefined)}>
      <div className="dialog-top"><span className="eyebrow">{detail.sku}</span><button className="button icon" onClick={() => setDetail(undefined)} aria-label="Đóng"><X size={18} /></button></div>
      {imagePath(detail.image_url) && <img className="detail-image" src={imagePath(detail.image_url)} alt={detail.name} />}
      <h2>{detail.name}</h2><p>{[detail.system, detail.door_type, detail.finish].filter(Boolean).join(' · ')}</p><p>{detail.description}</p>
      <button className="button primary" disabled={busy} onClick={() => { change(detail.id, 1); setDetail(undefined) }}>Thêm vào giỏ · {money(detail.price)}</button>
    </dialog>}
  </>
}
