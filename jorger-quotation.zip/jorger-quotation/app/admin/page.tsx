import Link from 'next/link'
import { adminContext } from '../../lib/database'
import { login, logout, saveProduct, updateStatus } from './actions'
import { money, type Order, type Product } from '../../lib/catalog'

const messages: Record<string, string> = {
  login: 'Email hoặc mật khẩu không hợp lệ.',
  product: 'Không lưu được sản phẩm. Kiểm tra mã SKU, giá, cấu hình và đường dẫn ảnh.',
  order: 'Không cập nhật được yêu cầu.',
  saved: 'Đã lưu thay đổi.',
  offline: 'Supabase chưa được kết nối.',
}
const statuses = { new: 'Mới', reviewing: 'Đang kiểm tra', confirmed: 'Đã xác nhận', closed: 'Đã đóng' }

function ProductForm({ product }: { product?: Product }) {
  return <form action={saveProduct} className="form admin-fields">
    {product && <input type="hidden" name="id" value={product.id} />}
    <label>Mã SKU<input name="sku" defaultValue={product?.sku} required maxLength={80} /></label>
    <label>Tên sản phẩm<input name="name" defaultValue={product?.name} required maxLength={180} /></label>
    <label>Dòng<select name="line" defaultValue={product?.line}><option value="fluorocarbon">Fluorocarbon</option><option value="eco">Eco</option></select></label>
    <label>Kiểu bán<select name="kind" defaultValue={product?.kind}><option value="part">Mã lẻ</option><option value="set">Bộ cửa</option></select></label>
    <label>Hệ nhôm<input name="system" defaultValue={product?.system} placeholder="Bắt buộc cho bộ cửa" maxLength={120} /></label>
    <label>Loại cửa<input name="door_type" defaultValue={product?.door_type} placeholder="Bắt buộc cho bộ cửa" maxLength={120} /></label>
    <label>Màu / hoàn thiện<input name="finish" defaultValue={product?.finish} maxLength={120} /></label>
    <label>Giá niêm yết (₫)<input type="number" name="price" defaultValue={product?.price} min={1} max={1000000000} required /></label>
    <label className="wide">Đường dẫn ảnh<input name="image_url" defaultValue={product?.image_url} placeholder="https://… hoặc /products/…" maxLength={2000} /></label>
    <label className="wide">Mô tả<textarea name="description" defaultValue={product?.description} maxLength={4000} /></label>
    <label className="check"><input type="checkbox" name="active" defaultChecked={product?.active ?? true} /> Hiển thị cho khách</label>
    <button className="button primary">{product ? 'Lưu thay đổi' : 'Thêm sản phẩm'}</button>
  </form>
}

export default async function Admin({ searchParams }: { searchParams: Promise<{ message?: string }> }) {
  const { db, user, admin } = await adminContext()
  const { message } = await searchParams
  const products = db && admin ? await db.from('products').select('*').order('sku') : null
  const orders = db && admin ? await db.from('orders').select('*, order_items(sku,name,quantity,unit_price)').order('created_at', { ascending: false }) : null
  return <main className="wrap admin">
    <div className="section-head"><div><Link href="/" className="eyebrow">← TRANG KHÁCH HÀNG</Link><h1>Quản trị JORGER</h1></div>{user && <form action={logout}><button className="button">Đăng xuất</button></form>}</div>
    {message && messages[message] && <p className="notice" role="status">{messages[message]}</p>}
    {!db ? <p className="notice">Kết nối Supabase để sử dụng khu vực quản trị.</p> : !user ?
      <form className="panel box form login" action={login}><h2>Đăng nhập</h2><label>Email<input name="email" type="email" autoComplete="username" required /></label><label>Mật khẩu<input name="password" type="password" autoComplete="current-password" required /></label><button className="button primary">Đăng nhập</button></form> :
      !admin ? <p role="alert" className="notice">Tài khoản này chưa có quyền quản trị.</p> : <>
        <nav className="actions"><a className="button" href="#products">Sản phẩm</a><a className="button" href="#orders">Báo giá & đơn hàng</a></nav>
        <section id="products" className="section">
          <h2>Sản phẩm</h2>
          <details className="panel box"><summary>Thêm sản phẩm</summary><ProductForm /></details>
          {products?.error && <p role="alert">Không tải được danh mục.</p>}
          {(products?.data as Product[] | null)?.map(product => <details key={product.id} className="panel box"><summary>{product.sku} · {product.name} · {money(product.price)}{!product.active && ' · Đang ẩn'}</summary><ProductForm product={product} /></details>)}
        </section>
        <section id="orders" className="section">
          <h2>Báo giá & đơn hàng</h2>
          {orders?.error && <p role="alert">Không tải được yêu cầu.</p>}
          {orders?.data?.length === 0 && <p className="muted">Chưa có yêu cầu.</p>}
          {(orders?.data as Order[] | null)?.map(order => <details key={order.id} className="panel box">
            <summary>{order.kind === 'quote' ? 'Báo giá' : 'Đơn hàng'} · {order.customer} · {money(order.total)} · {statuses[order.status as keyof typeof statuses]}</summary>
            <p>Mã {order.id}</p><p>{new Date(order.created_at).toLocaleString('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh' })} · {order.phone}</p>
            {order.notes && <p>{order.notes}</p>}
            <ul>{order.order_items.map(item => <li key={item.sku}>{item.sku} · {item.name} × {item.quantity} · {money(item.unit_price)} / đơn vị</li>)}</ul>
            <form action={updateStatus} className="actions"><input type="hidden" name="id" value={order.id} /><select aria-label="Trạng thái" name="status" defaultValue={order.status}>{Object.entries(statuses).map(([key, label]) => <option key={key} value={key}>{label}</option>)}</select><button className="button primary">Cập nhật</button></form>
          </details>)}
        </section>
      </>}
  </main>
}
