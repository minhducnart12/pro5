'use server'

import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import { adminContext, database } from '../../lib/database'
import { imagePath } from '../../lib/catalog'

export async function login(form: FormData) {
  const db = await database()
  if (!db) redirect('/admin?message=offline')
  const { error } = await db.auth.signInWithPassword({ email: String(form.get('email')), password: String(form.get('password')) })
  redirect(error ? '/admin?message=login' : '/admin')
}

export async function logout() {
  const db = await database()
  await db?.auth.signOut()
  redirect('/admin')
}

export async function saveProduct(form: FormData) {
  const { db, admin } = await adminContext()
  if (!db || !admin) redirect('/admin')
  const fields = ['sku', 'name', 'line', 'kind', 'system', 'door_type', 'finish', 'description', 'image_url'] as const
  const record = Object.fromEntries(fields.map(field => [field, String(form.get(field) ?? '').trim()]))
  const price = Number(form.get('price'))
  const id = String(form.get('id') ?? '')
  if (!Number.isInteger(price) || price < 1 || price > 1_000_000_000 || (record.image_url && !imagePath(record.image_url))) redirect('/admin?message=product')
  const data = { ...record, price, active: form.get('active') === 'on' }
  const result = id ? await db.from('products').update(data).eq('id', id).select('id').single() : await db.from('products').insert(data)
  if (result.error) redirect('/admin?message=product')
  revalidatePath('/')
  revalidatePath('/admin')
  redirect('/admin?message=saved#products')
}

export async function updateStatus(form: FormData) {
  const { db, admin } = await adminContext()
  if (!db || !admin) redirect('/admin')
  const result = await db.from('orders').update({ status: String(form.get('status')) }).eq('id', String(form.get('id'))).select('id').single()
  if (result.error) redirect('/admin?message=order')
  revalidatePath('/admin')
  redirect('/admin?message=saved#orders')
}
