import { Storefront } from '../components/storefront'
import { database } from '../lib/database'
import type { Product } from '../lib/catalog'

export default async function Page() {
  const db = await database()
  const result = db ? await db.from('products').select('*').eq('active', true).order('sku') : null
  return <Storefront products={(result?.data ?? []) as Product[]} offline={!result || !!result.error} />
}
