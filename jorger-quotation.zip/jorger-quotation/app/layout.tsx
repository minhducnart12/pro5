import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'JORGER Quotation | Báo giá & đặt hàng',
  description: 'Chọn bộ phụ kiện cửa JORGER, xem báo giá và gửi yêu cầu đặt hàng.',
}

export default function Layout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="vi"><body>{children}</body></html>
}
