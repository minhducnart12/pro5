'use server'

import { database } from '../lib/database'

export async function submitRequest(form: FormData, items: { product_id: string; quantity: number }[], id: string) {
  const db = await database()
  if (!db) return { error: 'Hệ thống tiếp nhận yêu cầu chưa được kết nối.' }
  const { data, error } = await db.rpc('submit_request', {
    request_id: id,
    request_kind: String(form.get('kind')),
    buyer: String(form.get('customer')),
    contact: String(form.get('phone')),
    message: String(form.get('notes') ?? ''),
    items,
  }).single<{ id: string; total: number }>()
  if (error || !data) return { error: 'Chưa thể gửi yêu cầu. Hãy tải lại nếu danh mục vừa thay đổi.' }
  return { receipt: data }
}
