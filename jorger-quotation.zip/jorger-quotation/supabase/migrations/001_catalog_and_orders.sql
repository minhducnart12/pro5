create table public.admins (
  user_id uuid primary key references auth.users on delete cascade
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  sku text unique not null check (length(sku) between 1 and 80),
  name text not null check (length(name) between 1 and 180),
  line text not null check (line in ('fluorocarbon','eco')),
  kind text not null check (kind in ('part','set')),
  system text not null default '',
  door_type text not null default '',
  finish text not null default '',
  description text not null default '',
  image_url text not null default '',
  price integer not null check (price between 1 and 1000000000),
  active boolean not null default true,
  check (kind = 'part' or (length(system) > 0 and length(door_type) > 0))
);

create table public.orders (
  id uuid primary key,
  kind text not null check (kind in ('quote','order')),
  customer text not null,
  phone text not null,
  notes text not null,
  status text not null default 'new' check (status in ('new','reviewing','confirmed','closed')),
  subtotal bigint not null,
  fluorocarbon_total bigint not null,
  discount bigint not null,
  total bigint not null,
  created_at timestamptz not null default now()
);

create table public.order_items (
  order_id uuid not null references public.orders on delete cascade,
  product_id uuid not null references public.products,
  sku text not null,
  name text not null,
  line text not null,
  quantity integer not null check (quantity between 1 and 1000),
  unit_price integer not null,
  primary key (order_id, product_id)
);

alter table public.admins enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

create policy "Read own admin membership" on public.admins for select to authenticated using (user_id = (select auth.uid()));
create policy "Public catalog" on public.products for select to anon, authenticated using (active);
create policy "Admin manages products" on public.products for all to authenticated
  using (exists(select 1 from public.admins where user_id = (select auth.uid())))
  with check (exists(select 1 from public.admins where user_id = (select auth.uid())));
create policy "Admin reads orders" on public.orders for select to authenticated
  using (exists(select 1 from public.admins where user_id = (select auth.uid())));
create policy "Admin updates orders" on public.orders for update to authenticated
  using (exists(select 1 from public.admins where user_id = (select auth.uid())))
  with check (exists(select 1 from public.admins where user_id = (select auth.uid())));
create policy "Admin reads order items" on public.order_items for select to authenticated
  using (exists(select 1 from public.admins where user_id = (select auth.uid())));

revoke all on public.admins, public.products, public.orders, public.order_items from anon, authenticated;
grant select on public.products to anon, authenticated;
grant select on public.admins, public.orders, public.order_items to authenticated;
grant insert, update on public.products to authenticated;
grant update (status) on public.orders to authenticated;

create function public.submit_request(request_id uuid, request_kind text, buyer text, contact text, message text, items jsonb)
returns table (id uuid, total bigint) language plpgsql security definer set search_path = '' as $$
declare
  available integer;
  amount bigint;
  eligible bigint;
  reduction bigint;
  snapshot jsonb;
begin
  if request_id is null or request_kind is null or request_kind not in ('quote','order')
    or coalesce(length(trim(buyer)),0) not between 2 and 120
    or coalesce(length(trim(contact)),0) not between 8 and 25
    or coalesce(length(message),0) > 1500
    or jsonb_typeof(items) is distinct from 'array' then
    raise exception 'Invalid request';
  end if;
  if jsonb_array_length(items) not between 1 and 100 then
    raise exception 'Invalid cart';
  end if;

  perform pg_advisory_xact_lock(hashtextextended(request_id::text, 0));
  return query select o.id, o.total from public.orders o
    where o.id = request_id and o.customer = trim(buyer) and o.phone = trim(contact);
  if found then return; end if;

  select count(*), sum(p.price::bigint * i.quantity),
    coalesce(sum(p.price::bigint * i.quantity) filter (where p.line = 'fluorocarbon'),0),
    jsonb_agg(jsonb_build_object('product_id',p.id,'sku',p.sku,'name',p.name,'line',p.line,'unit_price',p.price,'quantity',i.quantity))
  into available, amount, eligible, snapshot
  from jsonb_to_recordset(items) i(product_id uuid, quantity integer)
  join public.products p on p.id = i.product_id and p.active
  where i.quantity between 1 and 1000;

  if available <> jsonb_array_length(items) then raise exception 'Unavailable product'; end if;

  reduction := eligible * (case when eligible >= 10000000 then 35
    when eligible >= 5000000 then 32 else 30 end) / 100;

  insert into public.orders(id,kind,customer,phone,notes,subtotal,fluorocarbon_total,discount,total)
  values(request_id,request_kind,trim(buyer),trim(contact),coalesce(message,''),amount,eligible,reduction,amount-reduction);
  insert into public.order_items(order_id,product_id,sku,name,line,unit_price,quantity)
  select request_id, r.product_id, r.sku, r.name, r.line, r.unit_price, r.quantity
  from jsonb_to_recordset(snapshot) r(product_id uuid,sku text,name text,line text,unit_price integer,quantity integer);
  return query select request_id, amount-reduction;
end
$$;
revoke all on function public.submit_request(uuid,text,text,text,text,jsonb) from public;
grant execute on function public.submit_request(uuid,text,text,text,text,jsonb) to anon, authenticated;
