-- DỮ LIỆU THỬ. Giá và cấu hình bên dưới chỉ dùng để kiểm thử giao diện.
insert into public.products (sku, name, line, kind, system, door_type, finish, description, image_url, price) values
('DEMO-F01','Tay nắm Simple','fluorocarbon','part','','','Đen mờ','Tay nắm cửa đi kiểu dáng thanh gọn. Mẫu thử.','/products/D11009.webp',1290000),
('DEMO-F02','Bộ phụ kiện Simple','fluorocarbon','set','Xingfa 55','Cửa đi 1 cánh','Đen mờ','Bộ cấu hình mẫu cho cửa đi 1 cánh.','/products/D11009.webp',4650000),
('DEMO-F03','Bộ phụ kiện Simple','fluorocarbon','set','Xingfa 55','Cửa đi 2 cánh','Đen mờ','Bộ cấu hình mẫu cho cửa đi 2 cánh.','/products/D11009.webp',6800000),
('DEMO-E01','Tay nắm Eco','eco','part','','','Đen mờ','Tay nắm cửa đi thuộc dòng Eco. Mẫu thử.','',690000),
('DEMO-E02','Bộ phụ kiện Eco','eco','set','Xingfa 55','Cửa đi 1 cánh','Đen mờ','Bộ cấu hình Eco mẫu cho cửa đi 1 cánh.','',2890000)
on conflict (sku) do nothing;
